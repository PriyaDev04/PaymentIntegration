const proImages = [{
    id: 1,
    title: "Perfume",
    price: 8000,
    image: "../images/pro1.jpeg"
},
{
    id: 2,
    title: "LipStick",
    price: 3000,
    image: "../images/pro2.jpeg"
},
{
    id: 3,
    title: "Cream",
    price: 6000,
    image: "../images/pro3.jpeg"
}]

export default proImages;